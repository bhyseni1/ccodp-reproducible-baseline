CCODP — Paketa e ekzekutimit në Render

STATUSI
Paketa u përgatit dhe kontrolluesi web u testua lokalisht me 2 blloqe (18 prova). Nuk u publikua në Render dhe nuk ka rezultate cloud në këtë paketë. Matjet lokale të kontrollit të programit nuk u shtuan në punim.

ÇFARË DO TË EKZEKUTOHET
9 hyrjet e ruajtura CSV të benchmark-ut, gjithsej 38 245 rreshta; të njëjtat operacione pandas/SQLite nga research_pipeline.py; 30 blloqe dhe 270 prova. SHA-256 kontrollohet për hyrjet përpara ekzekutimit. Ky shërbim nuk kryen kontrollin e korpusit të plotë prej 1 483 245 rreshtash. Ai mbulon vetëm pjesën e matjes mbi nënbashkësitë e njëjta të ruajtura.

PUBLIKIMI
1. Vendosni përmbajtjen e kësaj dosjeje në një depo Git të lidhur me Render. Dosjet benchmark_inputs, inputs, metadata dhe code duhet të ruhen.
2. Në Render përdorni Blueprint nga render.yaml. Konfigurimi specifikon plan: free, Python 3.12.7 dhe një RUN_TOKEN të gjeneruar. Nuk kërkohet databazë, disk me pagesë apo worker i veçantë.
3. Pasi shërbimi të jetë aktiv, hapni URL-në e tij. Merrni RUN_TOKEN nga Environment në Render dhe përdoreni vetëm në faqen e këtij shërbimi.
4. Shtypni Run benchmark dhe prisni statusin completed. Shkarkoni rezultatin me Download results përpara se shërbimi falas të ndalet ose riniset.

REZULTATI
Arkivi përmban matjet CSV, përmbledhjet, kontrollet e integritetit, notebook-un Jupyter të ekzekutuar, kodin dhe environment.json. Mjedisi regjistron versionet reale, identifikuesin e shërbimit kur është i disponueshëm, commit-in, CPU-të e dukshme dhe kufijtë cgroup. Nuk regjistrohen çelësa API ose token-e. Lejohet një nisje e benchmark-ut për sesion të shërbimit.

KRAHASUESHMËRIA
Mjedisi i Render është Python i menaxhuar me paketa të përcaktuara, jo instalimi i plotë Anaconda i ekzekutimit fillestar. Ndryshimet e patch-it Python, SQLite, sistemit dhe burimeve duhet të shqyrtohen në environment.json. Matjet përshkruajnë këtë instancë dhe këto hyrje; nuk vlerësojnë elasticitet, kosto, latencë API apo ofrues cloud në përgjithësi. Rezultatet duhet të kontrollohen përpara se të shtohen në punim.

PLANI FALAS
Shërbimi free ka kufij të CPU-së, memories, orëve, bandwidth-it dhe build-it. Skedarët janë të përkohshëm dhe humben në restart ose spin-down. Zgjedhja e planit free nuk heq kufijtë apo rregullat e faturimit të llogarisë. Kontrolloni që shërbimi të mbetet në free dhe që përdorimi të jetë brenda kuotave.

BURIME ZYRTARE
https://render.com/docs/free
https://render.com/docs/blueprint-spec
https://render.com/docs/web-services
https://render.com/docs/environment-variables
