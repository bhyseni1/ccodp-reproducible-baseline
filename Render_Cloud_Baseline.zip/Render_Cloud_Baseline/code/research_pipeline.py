"""Reproducible source acquisition and LOCAL CSV portability experiment.

No cloud-provider, human-usability or live-migration results are simulated.
Run from the package root with the supplied Anaconda/Jupyter environment.
"""
from pathlib import Path
import csv, json, hashlib, time, datetime, platform, sys, os, random
import sqlite3, urllib.request, urllib.error, urllib.parse, itertools, math, importlib.metadata
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path.cwd()
SEED = 1729
REPETITIONS = 30
BENCHMARK_ROW_LIMIT = 10000
SOURCES = json.loads((ROOT/'metadata/source_registry.json').read_text())
for name in ['data','raw','metadata','results','figures','benchmark_inputs']:
    (ROOT/name).mkdir(exist_ok=True)

def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()

def download(url, path):
    """Stream an unchanged public response; retain attempts, timestamps and hash."""
    path = Path(path)
    attempts = []
    for attempt in range(1,4):
        start = time.perf_counter(); started = utc_now()
        try:
            req = urllib.request.Request(url, headers={'User-Agent':'OpenDataResearch/1.0'})
            with urllib.request.urlopen(req, timeout=120) as response:
                status = response.status
                content_type = response.headers.get('Content-Type','')
                final_url = response.url
                with path.with_suffix(path.suffix+'.part').open('wb') as handle:
                    while True:
                        chunk = response.read(1024*1024)
                        if not chunk: break
                        handle.write(chunk)
            path.with_suffix(path.suffix+'.part').replace(path)
            attempts.append({'attempt':attempt,'started_utc':started,'seconds':time.perf_counter()-start,'status':status})
            return {'requested_url':url,'final_url':final_url,'content_type':content_type,
                    'retrieved_utc':utc_now(),'bytes':path.stat().st_size,
                    'sha256':sha256_file(path),'attempts':attempts}
        except Exception as exc:
            attempts.append({'attempt':attempt,'started_utc':started,'seconds':time.perf_counter()-start,'error':repr(exc)})
            if attempt == 3:
                (ROOT/'results'/('FAILED_'+path.name+'.json')).write_text(json.dumps(attempts,indent=2))
                raise
            time.sleep(attempt*2)

def ordered_codes(category):
    index = category['index']
    return list(index) if isinstance(index,list) else [k for k,v in sorted(index.items(),key=lambda item:item[1])]

def paginated_csv(source, destination, page_size=20000):
    """Retrieve every row via ordered SODA CSV pages when a bulk export stalls."""
    endpoint=source['json_url'].removesuffix('.json')
    count_url=endpoint+'.json?'+urllib.parse.urlencode({'$select':'count(*)'})
    with urllib.request.urlopen(count_url,timeout=45) as response:
        expected=int(json.load(response)[0]['count'])
    pages=[];total=0;header=None;started=utc_now()
    temp=Path(destination).with_suffix('.csv.assembled')
    with temp.open('w',encoding='utf-8',newline='') as output:
        writer=csv.writer(output)
        for offset in range(0,expected,page_size):
            url=endpoint+'.csv?'+urllib.parse.urlencode({'$limit':page_size,'$offset':offset,'$order':':id'})
            page_path=ROOT/'raw'/(source['dataset_id']+'_page.csv')
            record=download(url,page_path);count=0
            with page_path.open(encoding='utf-8-sig',newline='') as handle:
                reader=csv.reader(handle);current=next(reader)
                if header is None:header=current;writer.writerow(header)
                elif current!=header:raise ValueError('CSV page schema changed')
                for row in reader:
                    if len(row)!=len(header):raise ValueError('Malformed page row')
                    writer.writerow(row);count+=1
            record.update(offset=offset,rows=count);pages.append(record);total+=count
            page_path.unlink()
            if count!=min(page_size,expected-offset):raise ValueError('Incomplete CSV page')
            (ROOT/'metadata'/(source['dataset_id']+'_pagination_progress.json')).write_text(json.dumps({'expected':expected,'received':total,'pages':pages},indent=2))
    with urllib.request.urlopen(count_url,timeout=45) as response:
        count_after=int(json.load(response)[0]['count'])
    if total!=expected:raise ValueError('Incomplete full CSV acquisition')
    temp.replace(destination)
    return {'requested_url':endpoint+'.csv','retrieved_utc':utc_now(),'started_utc':started,
        'bytes':Path(destination).stat().st_size,'sha256':sha256_file(destination),
        'rows_expected_before':expected,'rows_received':total,'rows_in_api_after':count_after,
        'row_count_stable':expected==count_after,'page_size':page_size,'order':':id','pages':pages,
        'note':'All rows reconstructed from native CSV API pages; one header; source column names retained.'}

def sparse_item(container, index):
    if isinstance(container,list):
        return (index < len(container),container[index] if index < len(container) else None)
    return str(index) in container,container.get(str(index))

def flatten_jsonstat(raw_path, csv_path):
    """Keep the full selected dimension grid, exact numeric token text and flags."""
    obj = json.loads(Path(raw_path).read_text(),parse_float=str)
    if obj.get('class') != 'dataset': raise ValueError('Expected JSON-stat dataset')
    dims = obj['id']; codes = [ordered_codes(obj['dimension'][d]['category']) for d in dims]
    if [len(x) for x in codes] != obj['size']: raise ValueError('Dimension size mismatch')
    labels = [obj['dimension'][d]['category'].get('label',{}) for d in dims]
    values = obj.get('value',{}); statuses = obj.get('status',{})
    fields = list(itertools.chain.from_iterable((d,d+'_label') for d in dims))
    fields += ['value','value_present','value_is_null','status','status_present']
    with Path(csv_path).open('w',encoding='utf-8',newline='') as handle:
        writer = csv.writer(handle); writer.writerow(fields)
        for index,keys in enumerate(itertools.product(*codes)):
            present,value = sparse_item(values,index); sp,status = sparse_item(statuses,index)
            row = list(itertools.chain.from_iterable((key,label.get(key,key)) for key,label in zip(keys,labels)))
            writer.writerow(row + ['' if value is None else str(value),str(present).lower(),str(present and value is None).lower(),'' if status is None else str(status),str(sp).lower()])
    # Independent inverse-index verification against the original response.
    lookup = [{code:i for i,code in enumerate(c)} for c in codes]
    mismatches = 0; count = 0
    with Path(csv_path).open(encoding='utf-8',newline='') as handle:
        for row in csv.DictReader(handle):
            index = 0
            for d,dimension_codes,mapping in zip(dims,codes,lookup):
                index = index*len(dimension_codes)+mapping[row[d]]
            present,value = sparse_item(values,index); sp,status = sparse_item(statuses,index)
            expected = ('' if value is None else str(value),str(present).lower(),str(present and value is None).lower(),'' if status is None else str(status),str(sp).lower())
            actual = tuple(row[k] for k in fields[-5:])
            mismatches += actual != expected; count += 1
    if mismatches or count != math.prod(obj['size']): raise AssertionError('JSON-stat conversion mismatch')
    return {'dimension_cells':count,'observed_values':sum(v is not None for v in (values.values() if isinstance(values,dict) else values)), 'conversion_mismatches':mismatches}

def acquire_one(source):
    i = source['dataset_id']; dest = ROOT/'data'/(i+'.csv')
    cache = ROOT/'metadata'/(i+'_acquisition.json')
    if cache.exists() and dest.exists():
        record = json.loads(cache.read_text())
        if sha256_file(dest) == record['csv_sha256']: return record
    record = dict(source)
    if source['platform'] != 'Eurostat':
        if i in {'mwzb-yiwb','4ijn-s7e5'}:
            record['data_download'] = paginated_csv(source,dest)
        else:
            record['data_download'] = download(source['csv_url'],dest)
        meta = ROOT/'metadata'/(i+'.json')
        record['metadata_download'] = download(source['metadata_url'],meta)
        record['scope'] = 'Full native CSV export; no row limit or period filter'
        record['csv_origin'] = 'Native CSV API pages assembled without omitted rows' if i in {'mwzb-yiwb','4ijn-s7e5'} else 'Native CSV export'
    else:
        raw = ROOT/'raw'/(i+'.json')
        record['data_download'] = download(source['json_url'],raw)
        record['conversion'] = flatten_jsonstat(raw,dest)
        record['scope'] = 'Germany (DE), 2023; all other dimension categories; full selected grid'
        record['csv_origin'] = 'Derived from JSON-stat; original JSON retained'
        (ROOT/'metadata'/(i+'.json')).write_bytes(raw.read_bytes())
    record['csv_sha256'] = sha256_file(dest)
    record['csv_bytes'] = dest.stat().st_size
    record['csv_path'] = 'data/'+i+'.csv'
    cache.write_text(json.dumps(record,ensure_ascii=False,indent=2))
    print('Acquired:',i,record['csv_bytes'],'bytes',flush=True)
    return record

def acquire_all():
    with ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(acquire_one,SOURCES))
    (ROOT/'metadata/acquisition_manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
    return records

def profile_data(records):
    profiles = []; columns = []; meta_rows = []
    csv.field_size_limit(100_000_000)
    for rec in records:
        i = rec['dataset_id']; path = ROOT/rec['csv_path']
        benchmark_path = ROOT/'benchmark_inputs'/(i+'.csv')
        with path.open(encoding='utf-8-sig',newline='') as inp, benchmark_path.open('w',encoding='utf-8',newline='') as out:
            reader = csv.reader(inp); header = next(reader)
            if len(header) != len(set(header)): raise ValueError('Duplicate header: '+i)
            writer = csv.writer(out); writer.writerow(header)
            blank = [0]*len(header); rows = 0; malformed = 0
            for row in reader:
                rows += 1
                if len(row) != len(header): malformed += 1; continue
                for j,value in enumerate(row): blank[j] += value == ''
                if rows <= BENCHMARK_ROW_LIMIT: writer.writerow(row)
        if malformed: raise ValueError('Malformed CSV rows: '+i)
        profiles.append({'dataset_id':i,'platform':rec['platform'],'rows':rows,'columns':len(header),'csv_bytes':path.stat().st_size,'blank_cells':sum(blank),'total_cells':rows*len(header),'blank_pct':100*sum(blank)/(rows*len(header)) if rows else np.nan,'malformed_rows':malformed,'benchmark_rows':min(rows,BENCHMARK_ROW_LIMIT),'benchmark_bytes':benchmark_path.stat().st_size,'csv_origin':rec['csv_origin'],'scope':rec['scope']})
        columns += [{'dataset_id':i,'column':name,'blank_count':n,'rows':rows,'blank_pct':100*n/rows if rows else np.nan} for name,n in zip(header,blank)]
        meta = json.loads((ROOT/'metadata'/(i+'.json')).read_text())
        euro = rec['platform']=='Eurostat'
        # Presence in the captured API payload only; this is not a portal usability score.
        meta_rows.append({'dataset_id':i,'platform':rec['platform'],
            'Title':bool(meta.get('label') if euro else meta.get('name')),
            'Publisher/source':bool(meta.get('source') if euro else meta.get('attribution')),
            'Description':bool(meta.get('description')),
            'Update timestamp':bool(meta.get('updated') if euro else meta.get('rowsUpdatedAt')),
            'Explicit licence field':bool(meta.get('license') or meta.get('licenseId')),
            'Field/dimension schema':bool(meta.get('dimension') if euro else meta.get('columns'))})
    frames = [pd.DataFrame(profiles),pd.DataFrame(columns),pd.DataFrame(meta_rows)]
    for frame,name in zip(frames,['dataset_profile','column_profile','metadata_presence']):frame.to_csv(ROOT/'results'/(name+'.csv'),index=False)
    return frames

def canonical_digest(frame):
    digest = hashlib.sha256()
    digest.update((json.dumps(list(frame.columns),ensure_ascii=False,separators=(',',':'))+'\n').encode())
    for row in frame.itertuples(index=False,name=None):
        digest.update((json.dumps(list(row),ensure_ascii=False,separators=(',',':'))+'\n').encode())
    return digest.hexdigest()

def read_csv_strings(path):
    return pd.read_csv(path,dtype=str,keep_default_na=False,na_filter=False,encoding='utf-8-sig')

def benchmark(profiles):
    rng = random.Random(SEED); trials = []; checks = []
    ids = list(profiles.dataset_id)
    for i in ids:
        p = ROOT/'benchmark_inputs'/(i+'.csv'); df = read_csv_strings(p)
        reference = canonical_digest(df)
        text = df.to_json(orient='records',force_ascii=False)
        back = pd.DataFrame(json.loads(text),columns=df.columns)
        json_ok = canonical_digest(back)==reference
        rt = ROOT/'benchmark_inputs'/(i+'_roundtrip.csv'); back.to_csv(rt,index=False)
        csv_ok = canonical_digest(read_csv_strings(rt))==reference
        checks.append({'dataset_id':i,'rows':len(df),'columns':len(df.columns),'canonical_sha256':reference,'json_roundtrip_pass':json_ok,'csv_roundtrip_pass':csv_ok})
        rt.unlink()
    references = {r['dataset_id']:r['canonical_sha256'] for r in checks}
    for block in range(1,REPETITIONS+1):
        order = ids.copy(); rng.shuffle(order)
        for position,i in enumerate(order,1):
            path = ROOT/'benchmark_inputs'/(i+'.csv')
            t0 = time.perf_counter_ns(); df = read_csv_strings(path); t1 = time.perf_counter_ns()
            con = sqlite3.connect(':memory:')
            try:
                t2 = time.perf_counter_ns(); df.to_sql('records',con,index=False,if_exists='fail'); t3 = time.perf_counter_ns()
                restored = pd.read_sql_query('SELECT * FROM records ORDER BY rowid',con,coerce_float=False); t4 = time.perf_counter_ns()
                valid = canonical_digest(restored)==references[i]
            finally: con.close()
            trials.append({'block':block,'position':position,'dataset_id':i,'rows':len(df),'bytes':path.stat().st_size,
                'csv_read_ms':(t1-t0)/1e6,'sqlite_import_ms':(t3-t2)/1e6,'sqlite_readback_ms':(t4-t3)/1e6,'integrity_pass':valid,'measured_at_utc':utc_now()})
        print('Completed local measurement block',block,'of',REPETITIONS,flush=True)
    trials = pd.DataFrame(trials); checks = pd.DataFrame(checks)
    trials.to_csv(ROOT/'results/benchmark_trials.csv',index=False)
    checks.to_csv(ROOT/'results/roundtrip_checks.csv',index=False)
    rows = []
    for i,g in trials.groupby('dataset_id',sort=False):
        row = {'dataset_id':i,'repetitions':len(g),'integrity_passes':int(g.integrity_pass.sum())}
        for metric in ['csv_read_ms','sqlite_import_ms','sqlite_readback_ms']:
            for label,q in [('median',.5),('q25',.25),('q75',.75),('p95',.95)]:row[metric+'_'+label]=g[metric].quantile(q)
        rows.append(row)
    summary = pd.DataFrame(rows); summary.to_csv(ROOT/'results/benchmark_summary.csv',index=False)
    return trials,checks,summary

def save_environment():
    packages = {}
    for name in ['notebook','jupyterlab','nbclient','ipykernel','pandas','numpy','scipy','matplotlib','seaborn','sqlalchemy']:
        try:packages[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:packages[name]=None
    info = {'captured_utc':utc_now(),'python':sys.version,'python_executable':sys.executable,
            'reference_anaconda_distribution':'2024.10-1','reference_installer_sha256':'3ba0a298155c32fbfd80cbc238298560bf69a2df511783054adfc151b76d80d8',
            'platform':platform.platform(),'machine':platform.machine(),'logical_cpus_visible':os.cpu_count(),
            'sqlite':sqlite3.sqlite_version,'packages':packages,'seed':SEED,'repetitions':REPETITIONS,
            'benchmark_row_limit':BENCHMARK_ROW_LIMIT,'measurement_scope':'Local process; warm filesystem cache; in-memory SQLite; no cloud-provider or participant experiment'}
    # Detect the actual backend on reruns. The executed notebook retains the original capture.
    from IPython import get_ipython
    shell = get_ipython()
    info['execution_backend'] = (type(shell).__module__+'.'+type(shell).__name__) if shell is not None else 'Python script'
    info['anaconda_python'] = 'Anaconda' in sys.version
    conda_metadata = Path(sys.prefix)/'conda-meta'
    info['anaconda_metapackage'] = [json.loads(p.read_text())['version'] for p in conda_metadata.glob('anaconda-[0-9]*.json')]
    for name in ['cpu.max','memory.max']:
        p=Path('/sys/fs/cgroup')/name
        if p.exists():info['cgroup_'+name]=p.read_text().strip()
    (ROOT/'metadata/execution_environment.json').write_text(json.dumps(info,indent=2))
    return info

def figures(profiles,meta,trials,summary):
    sns.set_theme(style='whitegrid',context='paper',font_scale=1.15)
    plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','pdf.fonttype':42})
    colors={'NYC Open Data':'#1758B3','Chicago Data Portal':'#7D42A6','Eurostat':'#147565'}
    labels={'cmjf-yawu':'NYC · School zones','c3uy-2p5r':'NYC · Air quality','mwzb-yiwb':'NYC · Expense budget','pb6d-zzuh':'Chicago · Schools','4ijn-s7e5':'Chicago · Food inspections','x394-e874':'Chicago · Budget 2024','educ_uoe_enra01':'Eurostat · Education','hlth_rs_bds1':'Eurostat · Hospital beds','gov_10a_main':'Eurostat · Government finance'}
    def save(fig,name):
        for ext in ['png','svg','pdf']:fig.savefig(ROOT/'figures'/(name+'.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
        plt.close(fig)
    order=list(profiles.dataset_id); y=np.arange(len(order)); names=[labels[i] for i in order]
    fig,axes=plt.subplots(1,2,figsize=(12,6),sharey=True)
    for ax,col,title in zip(axes,['rows','csv_bytes'],['Downloaded CSV rows','CSV size (MiB)']):
        values=profiles[col].to_numpy()/(2**20 if col=='csv_bytes' else 1)
        ax.barh(y,values,color=[colors[p] for p in profiles.platform],height=.65)
        ax.set_xscale('log');ax.set_title(title,loc='left',weight='bold');ax.set_yticks(y,names)
        ax.grid(axis='y',visible=False)
    axes[0].invert_yaxis();fig.suptitle('Public data corpus and declared Eurostat subsets',fontsize=15,weight='bold')
    fig.text(.01,.01,'USA: full native exports. Eurostat: Germany, 2023; complete selected dimension grids.',fontsize=9)
    fig.tight_layout(rect=(0,.04,1,.95));save(fig,'Figure_4_Corpus')
    long=trials.melt(id_vars=['dataset_id','block'],value_vars=['csv_read_ms','sqlite_import_ms','sqlite_readback_ms'],var_name='stage',value_name='milliseconds')
    fig,axes=plt.subplots(1,3,figsize=(15,6),sharey=True)
    for ax,stage,title in zip(axes,['csv_read_ms','sqlite_import_ms','sqlite_readback_ms'],['CSV parsing','SQLite import','SQLite readback']):
        vals=[long.loc[(long.dataset_id==i)&(long.stage==stage),'milliseconds'].values for i in order]
        ax.boxplot(vals,vert=False,labels=names,patch_artist=True,boxprops={'facecolor':'#DCE9F9'},medianprops={'color':'#1758B3'},showfliers=True)
        ax.set_xscale('log');ax.set_xlabel('Milliseconds (log scale)');ax.set_title(title,loc='left',weight='bold');ax.invert_yaxis()
    fig.suptitle('Local processing times across 30 randomized measurement blocks',fontsize=15,weight='bold')
    fig.text(.01,.01,'Up to 10,000 source-order rows per dataset; warm cache; in-memory SQLite. These are not cloud API latencies.',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,.95));save(fig,'Figure_5_Local_Performance')
    fig,ax=plt.subplots(figsize=(11,6))
    heat=meta.set_index('dataset_id').drop(columns='platform').loc[order].astype(int)
    heat.index=names
    sns.heatmap(heat,annot=True,fmt='d',cmap=sns.color_palette(['#F0F2F5','#1758B3'],as_cmap=True),vmin=0,vmax=1,cbar=False,linewidths=1,ax=ax)
    ax.set_title('Metadata fields present in the captured API response',loc='left',weight='bold',pad=18)
    ax.set_xlabel('');ax.set_ylabel('');ax.tick_params(axis='x',rotation=25)
    fig.text(.01,.01,'1 = nonempty field in this payload; 0 = absent. Information elsewhere on the website was not scored. This is not SUS.',fontsize=9)
    fig.tight_layout(rect=(0,.06,1,1));save(fig,'Figure_6_Metadata')
    fig,ax=plt.subplots(figsize=(11,6));values=profiles.blank_pct.to_numpy()
    ax.barh(y,values,color=[colors[p] for p in profiles.platform],height=.65);ax.set_yticks(y,names);ax.invert_yaxis()
    ax.set_xlabel('Empty CSV cells (%)');ax.set_xlim(0,max(values)*1.22 if max(values)>0 else 1)
    for j,v in enumerate(values):ax.text(v+.2,j,f'{v:.1f}%',va='center',fontsize=9)
    ax.set_title('Empty-cell prevalence in the delivered CSV files',loc='left',weight='bold')
    fig.text(.01,.01,'Empty cells may be valid or structurally unavailable. Eurostat grids retain missing values and empty status flags; percentages are not quality rankings.',fontsize=8.5)
    fig.tight_layout(rect=(0,.06,1,1));save(fig,'Figure_7_Empty_Cells')
    return sorted(p.name for p in (ROOT/'figures').glob('*'))

if __name__ == '__main__':
    env=save_environment();records=acquire_all();profiles,columns,meta=profile_data(records)
    trials,checks,summary=benchmark(profiles);figures(profiles,meta,trials,summary)
    print(profiles.to_string(index=False));print(summary.to_string(index=False))
