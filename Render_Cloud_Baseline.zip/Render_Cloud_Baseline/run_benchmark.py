"""Run the retained benchmark in Jupyter and keep a separate execution record.

The --local-validation option is a two-block software check, not a cloud result.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,platform,shutil,sqlite3,subprocess,sys
import urllib.request,zipfile,importlib.metadata
import nbformat
from ipykernel.inprocess.manager import InProcessKernelManager

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--local-validation',action='store_true');a=ap.parse_args()
 package=Path(__file__).resolve().parent
 if not a.local_validation and os.environ.get('RENDER')!='true':
  raise SystemExit('Run on Render, or use --local-validation for a two-block local software check.')
 expected=json.loads((package/'benchmark_sha256.json').read_text())
 for name,digest in expected.items():
  if sha(package/name)!=digest:raise RuntimeError('Input changed: '+name)
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
 label='Local_Validation' if a.local_validation else 'Render_Cloud'
 run=package/'runs'/(label+'_'+stamp);run.mkdir(parents=True)
 for directory in ['metadata','benchmark_inputs','results']:(run/directory).mkdir()
 shutil.copy2(package/'metadata/source_registry.json',run/'metadata/source_registry.json')
 for f in (package/'benchmark_inputs').glob('*.csv'):shutil.copy2(f,run/'benchmark_inputs'/f.name)
 code_path=package/'code/research_pipeline.py'
 env={'started_utc':stamp,'execution_context':'local_software_validation' if a.local_validation else 'render_web_service',
  'service_id':os.environ.get('RENDER_SERVICE_ID') if not a.local_validation else None,
  'region':os.environ.get('RENDER_REGION') if not a.local_validation else None,
  'git_commit':os.environ.get('RENDER_GIT_COMMIT') if not a.local_validation else None,
  'python':sys.version,'platform':platform.platform(),'sqlite':sqlite3.sqlite_version,
  'logical_cpus_visible':os.cpu_count(),'anaconda_python':'Anaconda' in sys.version,
  'packages':{n:importlib.metadata.version(n) for n in ['pandas','numpy','matplotlib','seaborn','ipykernel','notebook']},
  'benchmark_code_sha256':sha(code_path),'input_sha256':expected,
  'repetitions':2 if a.local_validation else 30,'seed':1729,
  'runtime_plan_requested':'free',
  'scope':'Warm-cache CSV read, in-memory SQLite import and SQL readback; retained source-order subsets only. No cloud API latency, cost, elasticity or full-corpus transfer measurement.'}
 for name in ['cpu.max','memory.max']:
  f=Path('/sys/fs/cgroup')/name
  if f.exists():env['cgroup_'+name]=f.read_text().strip()
 (run/'environment.json').write_text(json.dumps(env,indent=2))
 setup='''import importlib.util, pandas as pd
from pathlib import Path
spec=importlib.util.spec_from_file_location('retained_benchmark', CODE_PATH)
benchmark_module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchmark_module)
profiles=pd.read_csv(PROFILE_PATH)
benchmark_module.REPETITIONS=REPETITIONS
'''
 setup='CODE_PATH='+repr(str(code_path))+'\nPROFILE_PATH='+repr(str(package/'inputs/dataset_profile.csv'))+'\nREPETITIONS='+str(env['repetitions'])+'\n'+setup
 nb=nbformat.v4.new_notebook(cells=[
  nbformat.v4.new_markdown_cell('# '+label+' benchmark\nNew observations on retained input files. The original local measurements were not overwritten.'),
  nbformat.v4.new_code_cell(setup),
  nbformat.v4.new_code_cell("trials,checks,summary=benchmark_module.benchmark(profiles)\nassert len(trials)==9*REPETITIONS\nassert trials.integrity_pass.all()\nassert checks.json_roundtrip_pass.all() and checks.csv_roundtrip_pass.all()\ndisplay(summary)\nprint('Executed trials:',len(trials))")
 ],metadata={'kernelspec':{'name':'python3','display_name':'Python 3','language':'python'},'language_info':{'name':'python','version':platform.python_version()}})
 nbpath=run/(label+'_Benchmark_Executed.ipynb');original_cwd=Path.cwd();os.chdir(run)
 km=InProcessKernelManager();km.start_kernel();kc=km.client();kc.start_channels()
 try:
  for c in nb.cells:
   if c.cell_type!='code':continue
   mid=kc.execute(c.source,store_history=True,allow_stdin=False)
   km.kernel.stdout.flush();km.kernel.stderr.flush();c.outputs=[]
   for msg in kc.iopub_channel.get_msgs():
    if msg.get('parent_header',{}).get('msg_id')!=mid:continue
    if msg['msg_type']=='execute_input':c.execution_count=msg['content']['execution_count']
    if msg['msg_type'] in {'stream','execute_result','display_data','error'}:c.outputs.append(nbformat.v4.output_from_msg(msg))
   nbformat.write(nb,nbpath)
   for msg in kc.shell_channel.get_msgs():
    if msg.get('parent_header',{}).get('msg_id')==mid and msg['content'].get('status')=='error':
     raise RuntimeError('\n'.join(msg['content'].get('traceback',[])))
 finally:
  nbformat.write(nb,nbpath);kc.stop_channels();km.shutdown_kernel();os.chdir(original_cwd)
 env['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();env['status']='completed'
 (run/'environment.json').write_text(json.dumps(env,indent=2))
 archive=package/(run.name+'_Results.zip')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for f in list((run/'results').glob('*.csv'))+[nbpath,run/'environment.json',Path(__file__),code_path]:z.write(f,f.name)
 print('RESULT_ARCHIVE='+str(archive),flush=True)
 return archive

if __name__=='__main__':main()
