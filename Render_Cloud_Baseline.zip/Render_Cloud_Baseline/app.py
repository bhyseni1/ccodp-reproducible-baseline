"""Small authenticated web controller for one observed benchmark per service boot."""
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit
import hashlib,hmac,json,os,subprocess,sys,threading

ROOT=Path(__file__).resolve().parent
TOKEN=os.environ.get('RUN_TOKEN','')
STATE={'status':'ready','completed_blocks':0,'archive':None,'error':None}
LOCK=threading.Lock()

HTML='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>CCODP research benchmark</title><style>body{max-width:760px;margin:60px auto;padding:24px;font:17px/1.6 system-ui;color:#151515;background:#fafafa}h1{line-height:1.2}input,button{font:inherit;padding:12px;margin:6px 0}input{width:95%}button{background:#151515;color:white;border:0;cursor:pointer}pre{white-space:pre-wrap;background:#eee;padding:20px}small{color:#555}</style><h1>Cloud Computing for Open Data Platforms</h1><p>Run the retained CSV and SQLite benchmark on this service. Each completed run creates new timing observations and an executed Jupyter notebook.</p><p>9 frozen inputs · 30 randomized blocks · 270 trials</p><label>Run token<input id="token" type="password" autocomplete="off"></label><button onclick="run()">Run benchmark</button> <button onclick="download()">Download results</button><pre id="status">Loading service status...</pre><small>The timing results describe this service and these workloads. They do not measure cloud API latency, elasticity or costs. Download the result archive before this free service restarts or sleeps.</small><script>const auth=()=>({'Authorization':'Bearer '+document.getElementById('token').value});async function status(){const r=await fetch('/status');document.getElementById('status').textContent=JSON.stringify(await r.json(),null,2)}async function run(){const r=await fetch('/run',{method:'POST',headers:auth()});if(!r.ok)alert(await r.text());await status()}async function download(){const r=await fetch('/download',{headers:auth()});if(!r.ok){alert(await r.text());return}const u=URL.createObjectURL(await r.blob());const a=document.createElement('a');a.href=u;a.download='Render_Cloud_Results.zip';a.click();URL.revokeObjectURL(u)}status();setInterval(status,10000);</script></html>'''

def job():
 command=[sys.executable,str(ROOT/'run_benchmark.py')]
 if os.environ.get('CCODP_LOCAL_VALIDATION')=='1':command+=['--local-validation']
 try:
  p=subprocess.Popen(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  log=ROOT/'execution.log'
  with log.open('w') as f:
   for line in p.stdout:
    f.write(line);f.flush()
    if line.startswith('RESULT_ARCHIVE='):
     path=Path(line.strip().split('=',1)[1]).resolve()
     if path.parent!=ROOT:raise RuntimeError('Unexpected archive location')
     STATE['archive']=path.name
  code=p.wait()
  if code or not STATE['archive']:raise RuntimeError('Benchmark failed; inspect execution.log in the service logs.')
  STATE['completed_blocks']=2 if os.environ.get('CCODP_LOCAL_VALIDATION')=='1' else 30
  STATE['status']='completed'
 except Exception as e:STATE.update(status='failed',error=str(e));print(str(e),flush=True)

class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def send(self,code,body,kind='application/json',extra=None):
  if isinstance(body,dict):body=json.dumps(body).encode()
  if isinstance(body,str):body=body.encode()
  self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(body)))
  self.send_header('Cache-Control','no-store')
  for k,v in (extra or {}).items():self.send_header(k,v)
  self.end_headers();self.wfile.write(body)
 def authorized(self):return bool(TOKEN) and hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+TOKEN)
 def do_GET(self):
  path=urlsplit(self.path).path
  if path=='/health':return self.send(200,{'ok':True})
  if path=='/':return self.send(200,HTML,'text/html; charset=utf-8')
  if path=='/status':return self.send(200,{k:v for k,v in STATE.items() if k!='archive'})
  if path=='/download':
   if not self.authorized():return self.send(401,{'error':'Run token required'})
   if STATE['status']!='completed':return self.send(409,{'error':'No completed run'})
   return self.send(200,(ROOT/STATE['archive']).read_bytes(),'application/zip',{'Content-Disposition':'attachment; filename="Render_Cloud_Results.zip"'})
  return self.send(404,{'error':'Not found'})
 def do_POST(self):
  if urlsplit(self.path).path!='/run':return self.send(404,{'error':'Not found'})
  if not self.authorized():return self.send(401,{'error':'Run token required'})
  with LOCK:
   if STATE['status']!='ready':return self.send(409,{'error':'This service session already started a benchmark','status':STATE['status']})
   STATE['status']='running';threading.Thread(target=job,daemon=True).start()
  return self.send(202,{'status':'running'})

if __name__=='__main__':
 if len(TOKEN)<32:raise SystemExit('Configure RUN_TOKEN with at least 32 characters.')
 ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('PORT','10000'))),Handler).serve_forever()
